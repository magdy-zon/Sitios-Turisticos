<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Main styles for this application -->
<link href="{!! url('assets/materialize/css/materialize.min.css') !!}" rel="stylesheet">
<link href="{!! url('assets/css/colors.css') !!}" rel="stylesheet">
<link href="{!! url('assets/css/style.css') !!}" rel="stylesheet">
<link href="{!! url('assets/css/animations.css') !!}" rel="stylesheet">
