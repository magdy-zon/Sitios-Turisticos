<script  src="{!! url('/js/jquery.min.js') !!}"></script>
<!-- Bootstrap and necessary plugins -->
<script src="{!! url('/assets/materialize/js/materialize.min.js') !!}"></script>
