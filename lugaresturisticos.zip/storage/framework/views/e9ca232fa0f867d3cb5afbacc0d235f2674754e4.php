<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Main styles for this application -->
<link href="<?php echo url('assets/materialize/css/materialize.min.css'); ?>" rel="stylesheet">
<link href="<?php echo url('assets/css/colors.css'); ?>" rel="stylesheet">
<link href="<?php echo url('assets/css/style.css'); ?>" rel="stylesheet">
<link href="<?php echo url('assets/css/animations.css'); ?>" rel="stylesheet">
