<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
	<head>
			<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	    <meta name="description" content="Vacaciona">
	    <meta name="author" content="Interphy Soft">
	    <meta name="keyword" content="Sitios turísticos, vacaciona">
	    <link rel="shortcut icon" type="image/png" href="img/logo-tab.png">
			<title>Vacaciona</title>
			<?php echo $__env->make('layouts.includes.head_includes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>

	<body>
		<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<main>
			<?php echo $__env->yieldContent('content'); ?>
		</main>

		<?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.includes.footer_includes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('after_includes'); ?>
	</body>
	<script type="text/javascript">
		M.AutoInit();
	</script>
</html>
<?php /**PATH /Users/mJuarez/Documents/Laravel/lugaresturisticos/resources/views/layouts/app.blade.php ENDPATH**/ ?>