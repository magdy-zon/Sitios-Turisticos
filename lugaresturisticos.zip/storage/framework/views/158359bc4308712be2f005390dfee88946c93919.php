<script  src="<?php echo url('/js/jquery.min.js'); ?>"></script>
<!-- Bootstrap and necessary plugins -->
<script src="<?php echo url('/assets/materialize/js/materialize.min.js'); ?>"></script>
