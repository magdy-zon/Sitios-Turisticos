<nav class="nav-element background-green-2">
  <div class="nav-wrapper">
    <a href="/" class="brand-logo lincoln">Vacaciona</a>
    <ul id="nav-mobile" class="right hide-on-med-and-down">
      <li><a href="explora">Explora</a></li>
      <li><a href="#">Cotiza</a></li>
      <li><a href="#">Reseñas</a></li>
    </ul>
  </div>
</nav>
<?php /**PATH /Users/mJuarez/Documents/Laravel/lugaresturisticos/resources/views/layouts/includes/header.blade.php ENDPATH**/ ?>